package Modulo4.Sesion10.Evaluacion.Clases;

public interface IMiembroEquipo {
    String hablar();
    String celebrar();
    String amonestacionAmarilla();
    String amonestacionRoja();
}

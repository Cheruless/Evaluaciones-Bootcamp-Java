package Modulo4.Sesion7.Evaluacion.Interfaces;

public interface IProducto {
    void cambiarPrecio(int precio);
    boolean cantidadDisponible();
}

package Modulo4.Sesion7.Evaluacion.Interfaces;

public interface ICocina extends IProducto {
    int incluyeGas(int valorGas);
}

package Modulo4.Sesion9.Evaluacion.Clases;

public class Zapato {
    String marca;

    public Zapato(String marca) {
        this.marca = marca;
    }

    @Override
    public String toString() {
        return "Zapato {" + "marca=" + marca + '}';
    }
}

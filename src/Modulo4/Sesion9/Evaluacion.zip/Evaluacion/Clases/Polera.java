package Modulo4.Sesion9.Evaluacion.Clases;

public class Polera {
    private String color;

    public Polera(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Polera {" + "color=" + color + '}';
    }
}
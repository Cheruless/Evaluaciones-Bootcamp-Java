package Modulo4.Sesion8.Evaluacion.Clases.Ventas;

import java.util.Scanner;

public interface IVendedor {
    public Vendedor registrarVendedor();
}
